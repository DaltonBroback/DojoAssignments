//
//  NotesListViewController.swift
//  BeltExam
//
//  Created by Dalton on 5/25/17.
//  Copyright © 2017 Dalton Broback. All rights reserved.
//

import UIKit
import CoreData

class NotesListViewController: UITableViewController, UISearchBarDelegate, AddItemTableViewControllerDelegate {
    @IBOutlet weak var searchBar: UITableView!
    
    var notes = [NoteListItem]()
    
    var searchActive : Bool = false
    var filtered:[NoteListItem] = []
    
    
    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return notes.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NoteCell") as! ListItemTableViewCell
        let i = notes.count - 1 - indexPath.row
        let listitem = notes[i]
        cell.titleLabel?.text = listitem.note
        cell.dateLabel?.text = listitem.date
        return cell
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath){
        let i = notes.count - 1 - indexPath.row
        let note = notes[i]
        managedObjectContext.delete(note)
        do {
            try managedObjectContext.save()
        } catch {
            print("\(error)")
        }
        notes.remove(at: i)
        tableView.reloadData()
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "EditItemSegue", sender: indexPath)
        tableView.reloadData()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        if segue.identifier == "AddItemSegue"{
            let addItemTableViewController = segue.destination as! AddItemViewController
            
            addItemTableViewController.delegate = self
            
        } else if segue.identifier == "EditItemSegue" {
            let addItemTableViewController = segue.destination as! AddItemViewController
            addItemTableViewController.delegate = self
            
            let indexPath = sender as! NSIndexPath
            let i = notes.count - 1 - indexPath.row
            let theNote = notes[i]
            addItemTableViewController.textToAdd = theNote.note
            addItemTableViewController.indexPath = indexPath
        }
    }

    
    func fetchAllItems(){
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "NoteListItem")
        do{
            let result = try managedObjectContext.fetch(request)
            notes = result as! [NoteListItem]
        }
        catch{
            print("\(error)")
        }
    }
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        fetchAllItems()
        tableView.dataSource = self
        tableView.delegate = self
        searchBar.delegate = self
        
    }
    
    func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
        searchActive = true;
    }
    
    func searchBarTextDidEndEditing(searchBar: UISearchBar) {
        searchActive = false;
    }
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        searchActive = false;
    }
    
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {
        searchActive = false;
    }
    
    func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
        
        filtered = notes.filter({ (text) -> Bool in
            let tmp: NSString = text.note as! NSString
            let range = tmp.range(of: searchText, options: NSString.CompareOptions.caseInsensitive)
            return range.location != NSNotFound
        })
        if(filtered.count == 0){
            searchActive = false;
        } else {
            searchActive = true;
        }
        self.tableView.reloadData()
    }
    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        let searchPredicate = NSPredicate(format: "note CONTAINS[C] %@", searchText)
        let array = (filtered as NSArray).filtered(using: searchPredicate)
        
        print ("array = \(array)")
        
        if(array.count == 0){
            searchActive = false;
        } else {
            searchActive = true;
        }
        tableView.reloadData()
    }
    
    
    func itemSaved(by controller: AddItemViewController, with text: String, at indexPath: NSIndexPath?){
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM-dd-yyyy"
        let strDate = dateFormatter.string(from: Date())
        
        if let ip = indexPath {
            let i = notes.count - 1 - ip.row
            managedObjectContext.delete(notes[i])
            let note = NSEntityDescription.insertNewObject(forEntityName: "NoteListItem", into: managedObjectContext) as! NoteListItem
            note.note = text
            note.date = strDate
            notes.append(note)
        } else {
            let note = NSEntityDescription.insertNewObject(forEntityName: "NoteListItem", into: managedObjectContext) as! NoteListItem
            note.note = text
            note.date = strDate
            notes.append(note)
        }
        do {
            try managedObjectContext.save()
        } catch {
            print("\(error)")
        }
        if managedObjectContext.hasChanges {
            do {
                try managedObjectContext.save()
            } catch {
                let nserror = error as NSError
                print("Unresolved error \(nserror), \(nserror.userInfo)")
                abort()
            }
        }
        tableView.reloadData()
        dismiss(animated: true, completion: nil)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        fetchAllItems()
        tableView.reloadData()


    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
}
