//
//  ViewController.swift
//  BeltExam
//
//  Created by Dalton on 5/25/17.
//  Copyright © 2017 Dalton Broback. All rights reserved.
//

import UIKit
import CoreData

var NewText: String?

class AddItemViewController: UIViewController {
    
    var textToAdd: String?
    var indexPath: NSIndexPath?
    
    weak var delegate: AddItemTableViewControllerDelegate?

    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    @IBOutlet weak var textInput: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        textInput.text = textToAdd
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        let theText = textInput.text
        delegate?.itemSaved(by: self, with: theText!, at: indexPath)
    }

}

