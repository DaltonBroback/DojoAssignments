using System;
using DbConnection;

namespace ConsoleApplication
{
    public class User
    {
        public int id;
        public string FirstName;
        public string LastName;
        public string DummyData1;
        public string DummyData2;
        public string DummyData3;
        public string FavoriteNumber;
    }
}
