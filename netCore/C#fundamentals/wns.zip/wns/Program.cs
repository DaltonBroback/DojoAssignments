﻿using System;

namespace WizardNinjaSamurai
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Wizard wiz1 = new Wizard("Gandalf");
            Ninja nin1 = new Ninja("Sheena");
            Samurai sam1 = new Samurai("Jack");
        }
    }
}
